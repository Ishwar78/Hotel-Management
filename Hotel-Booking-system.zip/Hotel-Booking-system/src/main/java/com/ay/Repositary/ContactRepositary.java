package com.ay.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ay.Model.ContactMessage;

public interface ContactRepositary extends JpaRepository<ContactMessage, Long> {

}
