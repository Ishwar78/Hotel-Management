package com.ay.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ay.Model.Payment;

public interface PaymentRepositary extends JpaRepository<Payment, Long> {

}
