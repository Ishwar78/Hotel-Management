package com.ay.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ay.Model.User;

public interface UserRepositary extends JpaRepository<User, Long> {

	User findByEmail(String email);
}
