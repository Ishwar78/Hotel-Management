package com.ay.Repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ay.Model.Room;

public interface Roomrepositary extends JpaRepository<Room, Long> {

	List<Room> findByStatus(String status);
}
