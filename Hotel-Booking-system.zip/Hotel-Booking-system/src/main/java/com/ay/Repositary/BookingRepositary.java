package com.ay.Repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ay.Model.Booking;

public interface BookingRepositary extends JpaRepository<Booking, Long> {
	List<Booking> findByUserId(Long userId);

}
