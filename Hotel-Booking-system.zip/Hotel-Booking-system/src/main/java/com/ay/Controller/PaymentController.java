package com.ay.Controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ay.Model.Booking;
import com.ay.Model.Payment;
import com.ay.servic.BookingService;
import com.ay.servic.PaymentServce;

@Controller
@RequestMapping("/payment")
public class PaymentController {
	
	
	@Autowired
	private PaymentServce paymentservice;
	
	@Autowired
	private BookingService bookingService;

	
	
	@PostMapping("/pay")
	public String makePayment(@RequestParam Long bookingid,@RequestParam double amount) {
		
		Payment payment = new Payment();
		
		payment.setBookingid(bookingid);
		payment.setAmount(amount);
		payment.setPaymentStatus("Paid");
		payment.setPaymentDate(LocalDateTime.now());
		
		paymentservice.makePayment(payment);
		
		 Booking booking = bookingService.getBookingById(bookingid);
		    if (booking != null) {
		        booking.setBookingstatus("Paid");
		        bookingService.bookroom(booking); // Save the updated booking
		    }
		return "paymentsuccess";
	}
	

}
