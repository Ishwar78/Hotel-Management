package com.ay.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.ay.servic.RoomService;

@Controller
public class RoomController {

	@Autowired
	private RoomService roomservice;
	
	
	@GetMapping("/rooms/search")
	public String Searchrooms(Model model) {
		model.addAttribute("rooms", roomservice.getAllAvailableRooms());
		return "searchRooms";
	}
}
