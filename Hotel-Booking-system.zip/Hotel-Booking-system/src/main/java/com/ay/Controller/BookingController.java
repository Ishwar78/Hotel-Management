package com.ay.Controller;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ay.Model.Booking;
import com.ay.Model.Room;
import com.ay.servic.BookingService;
import com.ay.servic.RoomService;


@Controller
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingservice;
    
    @Autowired
    private RoomService roomService ;

    // Method for handling the room booking
    @PostMapping("/book")
    public String bookRoom(@RequestParam Long roomid, 
                           @RequestParam String Startdate, 
                           @RequestParam String EndDate,
                           Model model) {

    	try {
    	    
    	    Room room = roomService.getRoomById(roomid);
    	    int pricePerNight = room.getPriceper24hours(); // Assuming price is an int

    	    // Parse start and end dates
    	    LocalDate start = LocalDate.parse(Startdate);
    	    LocalDate end = LocalDate.parse(EndDate);

    	    // Calculate number of nights (end date is exclusive)
    	    long numberOfNights = ChronoUnit.DAYS.between(start, end);

    	    // Calculate total amount
    	    int totalAmount = (int) numberOfNights * pricePerNight;

    	    // Create new booking object
    	    Booking booking = new Booking();
    	    booking.setRoomid(roomid);
    	    booking.setUserId(1L);  // Replace with actual logged-in user ID
    	    booking.setStartDate(start);
    	    booking.setEndDate(end);
    	    booking.setAmount(totalAmount);
    	    booking.setBookingstatus("Confirmed");

    	    // Call the service to save the booking
    	    bookingservice.bookroom(booking);
    	    return "redirect:/bookings/confirm";

    	} catch (Exception e) {
            model.addAttribute("error", "Booking failed. Please try again.");
            return "errorPage";  // Redirect to an error page if booking fails
        }
    }
    @RequestMapping("/confirm")
    public String confirmPage(Model model) {
        model.addAttribute("message", "Your booking has been confirmed!");
        return "bookingConfirm";  // Redirect to bookingConfirm.html or bookingConfirm.jsp
    }
    // Method to show booking history
    @GetMapping("/history")
    public String bookingHistory(Model model) {
        try {
            // Assuming user ID is 1L (you can get the actual user ID dynamically)
            model.addAttribute("bookings", bookingservice.getbookingbuUserid(1L));
            return "bookingHistory";  // Return the booking history view
        } catch (Exception e) {
            model.addAttribute("error", "Error fetching booking history.");
            return "errorPage";  // Return error page if something goes wrong
        }
    }
   
    
}
