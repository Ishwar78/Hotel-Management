package com.ay.servic;

import com.ay.Model.Payment;

public interface PaymentServce {

	Payment makePayment(Payment payment);
	

}
