package com.ay.servic;

import java.util.List;

import com.ay.Model.Room;

public interface RoomService {

	List<Room>getAllAvailableRooms();
	Room getRoomById(Long id);
	Room saveRoom(Room room);
	
}
