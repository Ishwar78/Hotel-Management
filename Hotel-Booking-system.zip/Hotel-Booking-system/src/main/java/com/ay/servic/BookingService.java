package com.ay.servic;

import java.util.List;
import com.ay.Model.Booking;

public interface BookingService {
    Booking bookroom(Booking booking);
    List<Booking> getbookingbuUserid(Long userId);
    Booking getBookingById(Long id);  // In interface

}
