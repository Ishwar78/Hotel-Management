package com.ay.Service.Impl;

import org.springframework.stereotype.Service;

import com.ay.Model.Payment;
import com.ay.Repositary.PaymentRepositary;
import com.ay.servic.PaymentServce;

@Service
public class PaymentServiceImpl implements PaymentServce {

	final PaymentRepositary paymentrepositary;
	
	public PaymentServiceImpl(PaymentRepositary paymentrepositary) {
		this.paymentrepositary = paymentrepositary;
	}
	
	
	@Override
	public Payment makePayment(Payment payment) {
		return paymentrepositary.save(payment);
	}

}
