package com.ay.Service.Impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ay.Model.Room;
import com.ay.Repositary.Roomrepositary;
import com.ay.servic.RoomService;

@Service
public class RoomServiceImpl  implements RoomService{

	private final Roomrepositary roomrepositary;
	
	public RoomServiceImpl (Roomrepositary roomrepositary) {
		this.roomrepositary = roomrepositary;
	}
	
	@Override
	public List<Room> getAllAvailableRooms() {
		
		return roomrepositary.findByStatus("Available");
	}

	@Override
	public Room getRoomById(Long id) {
		
		return roomrepositary.findById(id).orElse(null);
	}

	@Override
	public Room saveRoom(Room room) {

		return roomrepositary.save(room);
	}

}
