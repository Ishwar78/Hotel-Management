package com.ay.Service.Impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ay.Model.Booking;
import com.ay.Repositary.BookingRepositary;
import com.ay.servic.BookingService;

@Service
public class BookingServiceImpl implements BookingService {

	
	private BookingRepositary bookingrepositary;
	
	public BookingServiceImpl(BookingRepositary bookingrepositary) {
		this.bookingrepositary = bookingrepositary;
	}
	
	
	@Override
	public Booking bookroom(Booking boking) {
		
		return bookingrepositary.save(boking);
	}

	@Override
	public List<Booking> getbookingbuUserid(Long userId) {
		
		return bookingrepositary.findByUserId(userId);
	}
	@Override
	public Booking getBookingById(Long id) {
	    return bookingrepositary.findById(id).orElse(null);
	}


}
